module imageservicemodule {
    exports com.udacity.catpoint.image.service to secuirityservicemodule;
    requires software.amazon.awssdk.metrics;
    requires software.amazon.awssdk.auth;
    requires org.slf4j;
    requires software.amazon.awssdk.core;
    requires software.amazon.awssdk.utils;
    requires software.amazon.awssdk.regions;
    requires software.amazon.awssdk.awscore;
    requires software.amazon.awssdk.services.rekognition;
    requires java.desktop;
}
