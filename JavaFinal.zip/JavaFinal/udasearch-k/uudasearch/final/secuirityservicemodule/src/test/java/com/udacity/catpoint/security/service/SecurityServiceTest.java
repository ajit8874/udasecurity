package com.udacity.catpoint.security.service;

import com.udacity.catpoint.image.service.ImageService;
import com.udacity.catpoint.security.application.StatusListener;
import com.udacity.catpoint.security.data.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.awt.image.BufferedImage;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class SecurityServiceTest {

    SecurityService securityService;
    @Mock
    StatusListener listener;

    @Mock
    SecurityRepository securityRepository;

    @Mock
    ImageService imageService;

    @Mock
    Sensor sensor;

    public Sensor getnewSensor(){
        return new Sensor("detected",SensorType.DOOR);
    }

    @BeforeEach
    void init(){
        try{
            securityService = new SecurityService(securityRepository, imageService);

            sensor = getnewSensor();

        } catch (IllegalArgumentException ex){
            ex.printStackTrace();
        }

    }

    // Test - 1

//    @Test
    @ParameterizedTest
    @ValueSource(booleans = {true, false})
    @DisplayName("If alarm is active, change in sensor state should not affect the alarm state.")
    void changeStatusToPending_sysArmed_sensorActivates() {
        try{

            try{
                when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);

                try{
                    when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.NO_ALARM);

                }catch (IllegalArgumentException ex){
                    ex.printStackTrace();
                }

            }catch (IllegalArgumentException ex){
                ex.printStackTrace();
            }
            try{
                securityService.changeSensorActivationStatus(sensor, true);
                verify(securityRepository).setAlarmStatus(AlarmStatus.PENDING_ALARM);
            }catch (IllegalArgumentException ex){
                ex.printStackTrace();
            }

        }catch (IllegalArgumentException ex){
            ex.printStackTrace();
        }
    }

    // Test - 2
//    @Test
    @ParameterizedTest
    @ValueSource(booleans = {true, false})
    @DisplayName("If alarm is active, change in sensor state should not affect the alarm state.")
    public void SetAlarmStatusToAlarm_sysArmedAndsensorActivated_AndstatePending()
    {
        try{

            try{
                when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
                when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
            }catch (IllegalArgumentException ex){
                ex.printStackTrace();
            }
            try{
                securityService.changeSensorActivationStatus(sensor,true);
                securityService.changeSensorActivationStatus(sensor,false);
            }catch (IllegalArgumentException ex){
                ex.printStackTrace();
            }

            verify(securityRepository).setAlarmStatus(AlarmStatus.ALARM);

        }catch (IllegalArgumentException ex){
            ex.printStackTrace();
        }

    }

    // Test - 3
    @Test
    public void NoAlarmState_AlarmPending_SensorInactive(){
        try{
           try{
               when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);

           }catch (IllegalArgumentException ex){
               ex.printStackTrace();
           }
            try{
                securityService.changeSensorActivationStatus(sensor, true);
                securityService.changeSensorActivationStatus(sensor, false);
            }catch (IllegalArgumentException ex){
                ex.printStackTrace();
            }

            verify(securityRepository).setAlarmStatus(AlarmStatus.NO_ALARM);

        }catch (IllegalArgumentException ex){
            ex.printStackTrace();
        }

    }

    // Test - 4

    @Test
    public void DoesNotAffectAlarmState_AlarmIsActiveAnd_ChangeIn_Sensor(){
        try{

            try{
                when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.ALARM);
                securityService.changeSensorActivationStatus(sensor, true);

                verify(securityRepository, never()).setAlarmStatus(any(AlarmStatus.class));
            }catch (IllegalArgumentException ex){
                ex.printStackTrace();
            }

            try{
                when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.ALARM);
                securityService.changeSensorActivationStatus(sensor, false);

                verify(securityRepository, never()).setAlarmStatus(any(AlarmStatus.class));
            }catch (IllegalArgumentException ex){
                ex.printStackTrace();
            }

        }catch (IllegalArgumentException ex){
            ex.printStackTrace();
        }
    }

    //test 5
    @Test
    public void noChangeInAlarmStateAlarmPending_sensorDeactivated_WhileAlreadyInactive(){
        try{
            try{
                sensor.setActive(false);
                when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);

            }catch (IllegalArgumentException ex){
                ex.printStackTrace();
            }

            securityService.changeSensorActivationStatus(sensor, false);

            verify(securityRepository,never()).setAlarmStatus(any(AlarmStatus.class));

        }catch (IllegalArgumentException ex){
            ex.printStackTrace();
        }

    }

    //test 6
    @Test
    public void changetoAlarmState_sensorActive_SystemPending(){
        try{
            when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
            try{
                securityService.changeSensorActivationStatus(sensor, true);

            }catch (IllegalArgumentException ex){
                ex.printStackTrace();
            }
            verify(securityRepository).setAlarmStatus(AlarmStatus.ALARM);

        }catch (IllegalArgumentException ex){
            ex.printStackTrace();
        }
    }

    // Test- 7
    @Test
    public void changeStatustoAlarmSys_imageServiceIdentifiesCat_sysInArmedHome(){
        try{
            when(securityService.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
            when(imageService.image_Contains_Cat(any(), ArgumentMatchers.anyFloat())).thenReturn(true);
            try{
                securityService.processImage(mock(BufferedImage.class));
                verify(securityRepository).setAlarmStatus(AlarmStatus.ALARM);
            }catch (IllegalArgumentException ex){
                ex.printStackTrace();
            }

        }catch (IllegalArgumentException ex){
            ex.printStackTrace();
        }
    }

    // Test- 8
    @Test
    public void TillSensorNotActive_imageDoesNotHaveCat_changeStatusToNOAlarm(){
        try{
            try{
                new HashSet().add(new Sensor("dfgds", SensorType.DOOR));
                new HashSet().add(new Sensor("dshfhgdf", SensorType.DOOR));
                new HashSet().add(new Sensor("fdgjfg", SensorType.DOOR));
            }catch (IllegalArgumentException ex){
                ex.printStackTrace();
            }

            try{
                when(securityService.getSensors()).thenReturn(new HashSet());
                when(imageService.image_Contains_Cat(any(), ArgumentMatchers.anyFloat())).thenReturn(false);
                securityService.processImage(mock(BufferedImage.class));
            }catch (IllegalArgumentException ex){
                ex.printStackTrace();
            }

            verify(securityRepository, times(1)).setAlarmStatus(AlarmStatus.NO_ALARM);
        }catch (IllegalArgumentException ex){
            ex.printStackTrace();
        }
    }

    // Test- 9
    @Test
    public void setStstusNoAlarm_ifSysDisarmed(){
        try{
            securityService.setArmingStatus(ArmingStatus.DISARMED);
            verify(securityRepository).setAlarmStatus(AlarmStatus.NO_ALARM);
        }catch (IllegalArgumentException ex){
            ex.printStackTrace();
        }
    }

    //test 10
    @Test
    public void allSensorInactiveARMED_AWAY_sysArmed(){

        try{
            try{
                Set<Sensor> sensors = new HashSet();
                sensors.add(new Sensor("dhd", SensorType.DOOR));
                sensors.add(new Sensor("dhgdf", SensorType.DOOR));
                when(securityService.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
                try{
                    when(securityService.getSensors()).thenReturn(sensors);

                }catch (IllegalArgumentException ex){
                    ex.printStackTrace();
                }

            }catch (IllegalArgumentException ex){
                ex.printStackTrace();
            }

            securityService.setArmingStatus(ArmingStatus.ARMED_AWAY);
            assertTrue(securityService.getSensors().stream().allMatch(sensor -> Boolean.FALSE.equals(sensor.getActive())));

        }catch (IllegalArgumentException ex){
            ex.printStackTrace();
        }

    }

    //test 11
    @Test
    public void allSensorInactiveARMED_HOME_sysArmed(){
        try{

            try{
                Set<Sensor> sensors = new HashSet();

                sensors.add(new Sensor("dhd", SensorType.DOOR));
                sensors.add(new Sensor("dhgdf", SensorType.DOOR));
                when(securityService.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
                try{
                    when(securityService.getSensors()).thenReturn(sensors);


                }catch (IllegalArgumentException ex){
                    ex.printStackTrace();
                }
            }catch (IllegalArgumentException ex){
                ex.printStackTrace();
            }
             try{
                 securityService.setArmingStatus(ArmingStatus.ARMED_HOME);

                 assertTrue(securityService.getSensors().stream().allMatch(sensor -> Boolean.FALSE.equals(sensor.getActive())));
             }catch (IllegalArgumentException ex){
                 ex.printStackTrace();
             }

        }catch (IllegalArgumentException ex){
            ex.printStackTrace();
        }
    }


    // Test- 12
    @Test
    public void setAlarmStstustoAlarm_ifSysISArmedHome_cameraShowsCat(){

        try{
            try{
                when(imageService.image_Contains_Cat(any(),anyFloat())).thenReturn(true);
                securityService.processImage(mock(BufferedImage.class));
            }catch (IllegalArgumentException ex){
                ex.printStackTrace();
            }
            securityService.setArmingStatus(ArmingStatus.ARMED_HOME);
            verify(securityRepository).setAlarmStatus(AlarmStatus.ALARM);

        }catch (IllegalArgumentException ex){
            ex.printStackTrace();
        }
    }

    // Test- 13
    @Test
    public void Deactivate_handleSensor(){
        try{
            try{
                when(securityService.getAlarmStatus()).thenReturn(AlarmStatus.ALARM);
                securityService.handleSensorDeactivated();
            }catch (IllegalArgumentException ex){
                ex.printStackTrace();
            }
            verify(securityRepository).setAlarmStatus(AlarmStatus.PENDING_ALARM);
        }catch (IllegalArgumentException ex){
            ex.printStackTrace();
        }
    }


    // Test- 14
    @Test
    public void Remove_and_add_Sensor(){

        try{
            try{
                securityService.addSensor(sensor);
                verify(securityRepository).addSensor(sensor);
            }catch (IllegalArgumentException ex){
                ex.printStackTrace();
            }
            securityService.removeSensor(sensor);
            verify(securityRepository).removeSensor(sensor);
        }catch (IllegalArgumentException ex){
            ex.printStackTrace();
        }

    }

    //     Test- 15
    @Test
    public void remove_and_add_listener(){
        try{
            try{
                securityService.addStatusListener(listener);

            }catch (IllegalArgumentException ex){
                ex.printStackTrace();
            }
            securityService.removeStatusListener(listener);

        }catch (IllegalArgumentException ex){
            ex.printStackTrace();
        }
    }

    //   Test- 16
    @Test
    public void Alarm_Status_check(){

        try{
            securityService.getAlarmStatus();

        }catch (IllegalArgumentException ex){
            ex.printStackTrace();
        }
    }



}









//ajit Phen0m@321







