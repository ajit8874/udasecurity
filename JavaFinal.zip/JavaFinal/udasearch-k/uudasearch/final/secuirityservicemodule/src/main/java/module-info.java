module secuirityservicemodule {
    requires software.amazon.eventstream;
    requires java.rmi;
    requires miglayout;
    requires jdk.crypto.cryptoki;
    requires imageservicemodule;
    requires java.compiler;
    requires java.desktop;
    requires java.prefs;
    requires software.amazon.awssdk.awscore;
    requires com.google.gson;
    requires jdk.charsets;
    requires com.google.common;
    opens com.udacity.catpoint.security.data to com.google.gson;
     }

